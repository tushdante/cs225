
#include "kdtreetest.h"

int main(int argc, char* argv[])
{
   unsigned int testCaseNumber = 0;
   std::cin >> testCaseNumber;
   testkdtree::runTestKDTree(testCaseNumber);
}
