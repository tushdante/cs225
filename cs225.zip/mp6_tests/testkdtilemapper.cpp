
#include "kdtilemappertest.h"

int main(int argc, char* argv[])
{
   unsigned int testCaseNumber = 0;
   std::cin >> testCaseNumber;
   testkdtilemapper::runTestKDTileMapper(testCaseNumber);
}
